"""Example configuration module for future project expansion."""
