# Telegram Video Bot — Starter Project

یہ ایک صاف ستھرا Python starter project ہے۔ کوڈ کے اندر identifiers اور commands انگریزی میں ہیں، کیونکہ Python اور Telegram API میں یہی عام طریقہ ہے۔ صارف کو دکھائے جانے والے پیغامات تبدیل کیے جا سکتے ہیں۔

## ابھی کیا کام کرتا ہے؟
- `/start` مینو
- `/help`, `/account`, `/premium`, `/support`, `/cancel`
- `/admin` کے ذریعے admin ID کی بنیادی جانچ
- HTTP/HTTPS لنک وصول کرنا
- ٹوکن `.env` میں رکھنا، سورس کوڈ میں نہیں

## اہم حد
یہ starter **ابھی ویڈیو ڈاؤن لوڈ نہیں کرتا**۔ لنک وصول کرنے کے بعد واضح پیغام دیتا ہے کہ downloader engine منسلک نہیں۔ Premium payments، database، daily quota، broadcast، channel membership check اور admin dashboard بھی ابھی مکمل نہیں ہیں۔ اسے مکمل production bot نہ سمجھیں۔

## سیٹ اپ
1. Python 3.11 یا اس سے نیا ورژن نصب کریں۔
2. ZIP extract کریں۔
3. فولڈر میں terminal کھولیں۔
4. dependencies نصب کریں:

   `python -m pip install -r requirements.txt`

5. `.env.example` کی کاپی بنا کر اس کا نام `.env` رکھیں۔
6. `.env` میں `BOT_TOKEN` کے سامنے BotFather سے لیا گیا token لکھیں۔
7. `ADMIN_IDS` میں اپنا numeric Telegram user ID لکھیں۔
8. بوٹ چلائیں:

   `python bot.py`

## ٹوکن کی حفاظت
- اصل token کسی چیٹ، اسکرین شاٹ، GitHub repository یا عوامی جگہ پر نہ بھیجیں۔
- اگر token کہیں ظاہر ہو گیا ہے تو BotFather میں `/revoke` سے اسے تبدیل کریں۔
- `.env` فائل کو کسی کے ساتھ شیئر نہ کریں۔

## اگلا مرحلہ
Production استعمال سے پہلے قانونی طور پر دستیاب مواد کے لیے downloader backend، محفوظ database، quota enforcement، error handling، logging، اور اگر ضرورت ہو تو verified payment provider الگ سے بنانا اور ٹیسٹ کرنا ہوگا۔
