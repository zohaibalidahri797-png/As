from pathlib import Path


def test_env_template_exists():
    assert Path(".env.example").is_file()


def test_bot_entrypoint_exists():
    assert Path("bot.py").is_file()
